ALTER USER 'root'@'localhost' identified by 'finalproject';
CREATE DATABASE CS275_finalproject;
USE CS275_finalproject;
CREATE TABLE gameState (player varchar(500), playerScore int);
